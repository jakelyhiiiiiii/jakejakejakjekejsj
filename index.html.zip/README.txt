JAKEWIDEWEB — 2000s CUTCORE PRINCESS EDITION

A hand-coded personal website using plain HTML, CSS, and JavaScript.

PREVIEW
1. Extract this ZIP.
2. Open the jakewideweb folder in Visual Studio Code.
3. Double-click index.html to preview it in your browser.

ADD GIFS / PHOTOS
Open script.js and add entries to the images list:
{
  url: "https://example.com/my-image.gif",
  caption: "My cute GIF"
}

Use a direct image URL (often ends in .gif, .png, .jpg, or .webp).
The image host must allow embedding/hotlinking.

EDIT THE SITE
- index.html: text, headings, sections, and links.
- style.css: colors, fonts, spacing, and layout.
- script.js: gallery image/GIF links.

PUBLISH
GitHub Pages can host this for free at a github.io address.
A custom .com domain requires separate registration and renewal fees.
