/*
  JAKEWIDEWEB GALLERY
  Add, remove, or edit items in the images list below.
  Use a DIRECT image URL (often ends in .gif, .png, .jpg, or .webp).
  Example:
  { url: "https://example.com/my-image.gif", caption: "My cool GIF" }
*/

const images = [
  {
    url: "<div class=\"tenor-gif-embed\" data-postid=\"8434051617938178753\" data-share-method=\"host\" data-aspect-ratio=\"1.245\" data-width=\"100%\"><a href=\"https://tenor.com/view/yotsuba-koiwai-anime-manga-girl-4-leaf-clover-gif-8434051617938178753\">Yotsuba Koiwai Anime Meme</a>from <a href=\"https://tenor.com/search/yotsuba+koiwai-memes\">Yotsuba Koiwai Memes</a></div> <script type=\"text/javascript\" async src=\"https://tenor.com/embed.js\"></script>",
      caption: "hai!",
      url: "https://tenor.com/view/yotsuba-koiwai-anime-manga-girl-4-leaf-clover-gif-8434051617938178753"
  },
  {
    url: "https://tenor.com/view/hatsune-miku-anime-vocaloid-lamazep-dance-gif-16231326",
    caption: "im so happyy"
  },
  {
    url: "https://tenor.com/view/teto-kasane-teto-chibi-vocaloid-utauloid-gif-6046312414942326109",
    caption: "!!!!!!"
  }
];

const gallery = document.getElementById("galleryGrid");

  function getTenorEmbedUrl(url) {
    try {
      const parsedUrl = new URL(url, window.location.href);
      if (parsedUrl.hostname !== "tenor.com" && !parsedUrl.hostname.endsWith(".tenor.com")) {
        return null;
      }

      const postId = parsedUrl.pathname.match(/(\d+)\/?$/)?.[1];
      return postId ? `https://tenor.com/embed/${postId}` : null;
    } catch {
      return null;
    }
  }

images.forEach((item) => {
  const card = document.createElement("figure");
  card.className = "gallery-card";

    const tenorEmbedUrl = getTenorEmbedUrl(item.url);
    if (tenorEmbedUrl) {
      const embed = document.createElement("iframe");
      embed.src = tenorEmbedUrl;
      embed.title = item.caption || "Tenor GIF";
      embed.loading = "lazy";
      embed.allowFullscreen = true;
      card.appendChild(embed);
    } else {
      const img = document.createElement("img");
      img.src = item.url;
      img.alt = item.caption || "Gallery image";
      img.loading = "lazy";
      img.onerror = () => card.classList.add("broken");
      card.appendChild(img);
    }

  const caption = document.createElement("figcaption");
  caption.textContent = item.caption || "Untitled image";

    card.appendChild(caption);
  gallery.appendChild(card);
});
